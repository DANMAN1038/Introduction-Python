pounds = input("Enter weight in pounds: ")
x = float(pounds)
print(x*.454)
