number = input("Enter the four digit integer: ")
number_a = int(number)
digit_a = number_a//1000
quotient_a = number_a - (digit_a*1000)
digit_b = quotient_a//100
quotient_b = number_a - (digit_a*1000) - (digit_b*100)
digit_c = quotient_b//10
quotient_c = number_a - (digit_a*1000) - (digit_b*100) - (digit_c*10)
digit_d = quotient_c//1
print(digit_a,
      digit_b,
      digit_c,
      digit_d)
