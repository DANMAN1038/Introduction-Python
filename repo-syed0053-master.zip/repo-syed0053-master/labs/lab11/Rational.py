class Rational: 
    def __init__(self, num=0, den=1):  
        self.numerator = num 
        if den == 0:  
            self.denominator = 1
        elif den == 1:
            self.denominator = ''
        elif num == 0:
            self.denominator = 0
        else: 
            self.denominator = den
    def scale (self, scales):
        return str(self.numerator*scales) + '/' + str(self.denominator*scales)
    def __str__(self):
        if self.denominator == '':
            return str(self.numerator)
        elif self.denominator == 0:
            return 0
        else:
            return str(self.numerator) + '/' + str(self.denominator)

