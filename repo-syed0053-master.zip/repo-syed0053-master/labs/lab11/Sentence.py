class Sentence:
    def __init__(self, string):
        self.var = string
    def getSentence(self):
        return str(self.var)
    def getWords(self):
        new_list = []
        self.var = self.var.split()
        for ele in self.var:
            new_list.append(self.var)
        return new_list
    def getLength(self):
        characters = 0
        self.var = self.var.split(',')
        for ele in self.var:
            for i in ele[0:]:
                characters += 1
        return characters
    def getNumWords(self):
        counter = 0
        self.var = self.var.split()
        for ele in self.var:
            counter += 1
        return counter
