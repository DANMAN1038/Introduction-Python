class Poly:
    def __init__(self, coefficient = [0]):
        self.coefficient = coefficient
    def degree(self):
        return len(self.coefficient) - 1
    def insertTerm(self, location, term):
        n = len(self.coefficient) - 1
        while n < location:
            self.coefficient.append(0)
            n += 1
        self.coefficient.append(term)
        return self.coefficient
        
