def min_max_nums(text):
    new_list = text.split()
    long = new_list[0]
    short = new_list[0]
    for ele in new_list:
        if len(long) < len(ele):
            long = ele
    for ele in new_list:
        if len(short) > len(ele):
            short = ele
    return (long, short)
print(min_max_nums("The yellow kite was flying in the bright blue sky"))


    
