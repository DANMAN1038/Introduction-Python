def earthquake(name):
    fp = open(name, 'r')
    newname = fp.readline()
    lastname = (newname).split(',')
    for ele in range(0,len(lastname)):
        print(ele, lastname[ele])
        print('\n')
earthquake('2.5_day.csv')
