def word_count(fname):
    fp = open(fname)
    newname = (fp).read().strip()
    lastname = str(newname).split()
    words = 0
    for ele in lastname:
        words += 1
    print("Number of words are: ", words)
    fp.close()
word_count("word_count.py")
