import random
def synthetic(name):
    fp = open(name,'w')
    x = 0
    for x in range(100):
        x += 1
        z = str(x)
        y = str(random.randint(-1000,1000))
        fp.write(z + "," + y + "\n")
    fp.close()
synthetic("name")
