import turtle
myt = turtle.Turtle()
myt.penup()
myt.goto(40,40)
myt.circle(100)
myt.pendown()
myt.circle(100)

myt.fillcolor("blue") 
myt.begin_fill()
myt.circle(100)
myt.end_fill()
