import math
def shortest_dist(a):
    m = []
    for i in range(len(a)):
        point1 = a[i]
        for j in range(len(a)-1):
            point2 = a[j+1]
            distance = dist(point1,point2)
            m.append(distance)
            print(m)
def dist(a,b):
    distance = math.sqrt(((a[0]-b[0])**2) + (a[1]-b[1])**2)
dist([10, 78], [-2, 50])
