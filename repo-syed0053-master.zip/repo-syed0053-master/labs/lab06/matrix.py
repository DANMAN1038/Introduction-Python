def matrix(n,init):
    fulllist = []
    sublist = []
    for i in range(n):
        for k in range(n):
            sublist.append(init)
        fulllist.append(sublist)
        sublist = []
    return fulllist
def identity(n):
    m = matrix(n,0)
    for row in range(len(m)):
        for column in range(len(m[row])):
            if column == row:
                m[row][column] = 1
    return m
print(identity(3))
