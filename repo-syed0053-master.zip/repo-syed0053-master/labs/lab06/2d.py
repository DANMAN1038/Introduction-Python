def order(m):
    print(len(m)
order([1,2,3])
