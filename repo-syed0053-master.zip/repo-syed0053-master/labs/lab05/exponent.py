x = int(input("Enter the first positive integer: "))
y = int(input("Enter the second positive integer: "))
rounds = 0
def expo(x,y):
    if y == 0:
        return 1
    answer = x
    increment = x
    for i in range(1,y):
        for j in range(1,x):
            answer += increment
        increment = answer
    return answer
print(expo(x,y))
