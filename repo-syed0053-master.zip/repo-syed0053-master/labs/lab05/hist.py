rolls = 0
my_list = [0,0,0,0,0,0,0,0,0,0,0,0,0]
import random
while rolls < 10000:
    x = random.randint(1,6)
    y = random.randint(1,6)
    z = x + y
    my_list[z] += 1
    rolls += 1
for i in range(len(my_list)):
    if i > 1:
        print(format(i, '2d'), ":", format(my_list[i], "5d"))
