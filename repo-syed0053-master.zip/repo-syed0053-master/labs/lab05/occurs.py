letter_in = True
while letter_in == True:
    letter_in = True

    word = str(input("Input word",))
    if len(word) == 0:
        letter_in = False
    else:
        word = word.lower()
        words_list = []
        words = []
        for char in word:
            word_list.append(char)
        letter = word_list[0]
        if letter in word_list[1:]:
            words.append(word)
print(words)
