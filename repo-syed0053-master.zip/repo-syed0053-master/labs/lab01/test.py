# test.py
#
# Program to print 'hello world to the terminal'

def main():
    print('hello world!')

if __name__ == '__main__':
    main()


