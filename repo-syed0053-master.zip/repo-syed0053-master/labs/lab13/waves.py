import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
temp = np.linspace(-6,6,100)
y = np.sin(temp)
plt.plot(y)
plt.xlabel("x axis")
plt.ylabel("y axis")
plt.title("My first matplot")
plt.show()
#print(y)
