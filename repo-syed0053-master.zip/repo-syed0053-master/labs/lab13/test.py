import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
arr = np.array([1,2,3])
temp = np.random.rand(1)
temp2 = np.random.rand(3,4)
temp3 = np.linspace(-6, 6, 100)
N = 50
x = np.random.rand(N)
y = np.random.rand(N)
plt.scatter(x,y)
plt.xlabel("x axis")
plt.ylabel("y axis")
plt.title("My first matplot")
plt.savefig(test.py)
plt.show()
#print(temp2)
