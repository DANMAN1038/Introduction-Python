import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
df = pd.read_csv("titanic.csv")
ages = df['Age'].values
#ages = df.ages[0][2]
#print(ages)
#x = df.sort_values('Name',ascending=False)
#print(x)
ages_ascending = df.sort_values('Age', ascending=True)
ages_ascending2 = list(ages_ascending['Age'])
ages_ascending2.sort()
youngest = ages_ascending2[0]
for i,ele in enumerate(ages):
    if ele == youngest:
        youngest_name = df['Name'][i]
print(youngest_name)
fare = df['Fare'][0:].values
fare_ascending = df.sort_values('Fare', ascending=True)
fare_ascending2 = list(fare_ascending['Fare'])
fare_ascending2.sort()
cheapest = fare_ascending2[0]
for i,ele in enumerate(fare):
    if ele == cheapest:
        cheapest_name = df['Name'][i]
print(cheapest_name)
#print((list(fare_ascending['Fare'][0]).sort))
